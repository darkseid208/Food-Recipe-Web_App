document.addEventListener("DOMContentLoaded", () => {
  const path = window.location.pathname;

  // ---------------- PAGE FLAGS ----------------
  const isLoginPage = path.includes("login.html");
  const isSignupPage = path.includes("signup.html");
  const isMainPage = path.includes("index.html");
  const isWishlistPage = path.includes("wishlist.html");
  const isCategoriesPage = path.includes("categories.html"); 

  // ---------------- PAGE CLASS FOR CSS ----------------
  if (isLoginPage) document.body.classList.add("login-page");
  if (isSignupPage) document.body.classList.add("signup-page");
  if (isMainPage) document.body.classList.add("front-page");

  // ---------------- REMOVE HEADER ON SPECIFIC PAGES ----------------
  if (isWishlistPage) {
    const header = document.querySelector("header");
    if (header) header.remove();
  }

  // ---------------- AUTH CHECK ----------------
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  if (!isLoggedIn && (isMainPage || isWishlistPage)) {
    document.body.style.display = "none";
    window.location.href = "login.html";
    return;
  } else {
    document.body.style.display = "block";
  }

  // ---------------- LOGIN PAGE ----------------
  if (isLoginPage) {
    const loginBtn = document.getElementById("loginBtn");
    loginBtn?.addEventListener("click", () => {
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      if (!email || !password) return alert("Enter email and password!");
      const users = JSON.parse(localStorage.getItem("users")) || [];
      const user = users.find(u => u.email === email && u.password === password);
      if (user) {
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("currentUser", user.username);
        window.location.href = "index.html";
      } else alert("Invalid email or password!");
    });
    return;
  }

  // ---------------- SIGNUP PAGE ----------------
  if (isSignupPage) {
    const signupBtn = document.getElementById("signupBtn");
    signupBtn?.addEventListener("click", () => {
      const username = document.getElementById("username").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();
      if (!username || !email || !password) return alert("Enter username, email, and password!");
      let users = JSON.parse(localStorage.getItem("users")) || [];
      if (users.some(u => u.email === email)) return alert("Email already exists!");
      users.push({ username, email, password });
      localStorage.setItem("users", JSON.stringify(users));
      alert("Signup successful! Login now.");
      window.location.href = "login.html";
    });
    return;
  }

  // ---------------- LOGOUT ----------------
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("currentUser");
      localStorage.removeItem("wishlist");
      window.location.href = "login.html";
    });
  }

  // ---------------- WISHLIST PAGE ----------------
 if (isWishlistPage) {
    // Hide Home button
    const homeBtn = document.querySelector(".Home-button");
    if (homeBtn) homeBtn.style.display = "none";

    const wishlistContainer = document.getElementById("wishlistContainer");

    function renderWishlist() {
        const wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
        wishlistContainer.innerHTML = wishlist.length
            ? wishlist.map(r => `
                <div class="recipe">
                    <img src="${r.image}" alt="${r.title}" style="width:200px;">
                    <h3>${r.title}</h3>
                    <p><strong>Origin:</strong> ${r.area || "N/A"}</p>
                    <button class="remove-btn" data-id="${r.id}">🗑</button>
                </div>`).join('')
            : "<p>No recipes in wishlist!</p>";

        document.querySelectorAll(".remove-btn").forEach(btn => {
            btn.addEventListener("click", e => {
                const id = e.target.dataset.id;
                const updated = JSON.parse(localStorage.getItem("wishlist"))
                    .filter(r => r.id != id);
                localStorage.setItem("wishlist", JSON.stringify(updated));
                renderWishlist();
            });
        });
    }

    renderWishlist();
    return;
}


  // ---------------- MAIN PAGE ----------------
  const searchbox = document.querySelector(".searchbox");
  const SearchBtn = document.querySelector(".SearchBtn");
  const voiceBtn = document.querySelector(".voice-search-btn");
  // make these let so we can create fallback modal if not present
  let recipeDetailsContent = document.querySelector(".recipe-details-content");
  let recipeCloseBtn = document.querySelector(".recipe-close-btn");

  // If the modal elements do not exist (e.g. categories.html), create them dynamically.
  if (!recipeDetailsContent) {
    const modal = document.createElement("div");
    // keep class names consistent with your CSS
    modal.className = "recipe-details";
    modal.style.display = "none";
    modal.innerHTML = `
      <div class="recipe-details-content"></div>
      <button class="recipe-close-btn" aria-label="Close recipe">
      <i class="fas fa-times"></i></button>
    `;
    document.body.appendChild(modal);
    recipeDetailsContent = modal.querySelector(".recipe-details-content");
    recipeCloseBtn = modal.querySelector(".recipe-close-btn");
  }

  function hideHero() {
    document.body.classList.remove("front-page");
    const hero = document.querySelector(".hero");
    if (hero) hero.style.display = "none";
  }

  // wire close btn if present
  if (recipeCloseBtn) {
    recipeCloseBtn.addEventListener("click", () => {
      if (recipeDetailsContent && recipeDetailsContent.parentElement) {
        recipeDetailsContent.parentElement.style.display = "none";
      }
    });
  }

  // ---------------- VOICE SEARCH ----------------
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRecognition && voiceBtn && searchbox) {
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;

    let voicePopup;

    function createVoicePopup() {
      voicePopup = document.createElement("div");
      voicePopup.className = "voice-popup";
      voicePopup.innerHTML = `
        <img src="voice.jpg" class="mic-icon" alt="Listening">
        <div class="voice-bars">
          <div></div><div></div><div></div><div></div><div></div>
        </div>`;
      document.body.appendChild(voicePopup);

      // Keep bouncing animation always
      const bars = voicePopup.querySelectorAll(".voice-bars div");
      bars.forEach((bar, i) => {
        bar.style.animation = `bounce 0.9s ${i * 0.1}s infinite ease-in-out`;
      });
    }

    function removeVoicePopup() {
      if (voicePopup) {
        voicePopup.remove();
        voicePopup = null;
      }
    }

    recognition.addEventListener("start", () => {
      createVoicePopup();
    });

    recognition.addEventListener("result", (event) => {
      const transcript = event.results[0][0].transcript.replace(/[.,/#!$%^&*;:{}=\`()]/g, "").trim();
      if (transcript) {
        searchbox.value = transcript;
        hideHero();
        showRecipePage(transcript);
      }
    });

    recognition.addEventListener("end", () => {
      removeVoicePopup();
    });

    voiceBtn.addEventListener("click", () => recognition.start());
  }

  // ---------------- WISHLIST ADD ----------------
 function addToWishlist(recipe) {
  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

  // Prevent duplicates
  if (wishlist.some(r => r.id == recipe.id)) {
    alert("Already in Wishlist");
    return;
  }

  // If origin or category or instructions missing → fetch full details
  if (recipe.area === "N/A" || !recipe.category || !recipe.instructions) {
    fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${recipe.id}`)
      .then(res => res.json())
      .then(data => {
        if (data.meals && data.meals[0]) {
          const full = data.meals[0];
          const fullRecipe = {
            id: full.idMeal,
            title: full.strMeal,
            image: full.strMealThumb,
            area: full.strArea || "N/A",
            category: full.strCategory || "",
            instructions: full.strInstructions || "",
          };
          wishlist.push(fullRecipe);
          localStorage.setItem("wishlist", JSON.stringify(wishlist));
          alert(`${fullRecipe.title} added to Wishlist!`);
        }
      })
      .catch(() => {
        // fallback if API fails
        wishlist.push(recipe);
        localStorage.setItem("wishlist", JSON.stringify(wishlist));
        alert(`${recipe.title} added with basic info.`);
      });
  } else {
    wishlist.push(recipe);
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
    alert(`${recipe.title} added to Wishlist!`);
  }
}


  // ---------------- PROFILE ----------------
// SINGLE PROFILE BUTTON HANDLER
profileBtnDropdown?.addEventListener("click", (e) => {
  e.stopPropagation();
  threeDotDropdown.classList.remove("show");

  // Hide main content sections
  document.querySelectorAll("header, main, .hero, .fe-box").forEach(el => el.style.display = "none");
  document.body.classList.remove("front-page");

  // Remove old profile headings/tables/buttons
  document.querySelectorAll(".profile-heading, .profile-table, .remove-all-btn").forEach(el => el.remove());

  // Create heading
  const heading = document.createElement("h2");
  heading.textContent = "Accounts";
  heading.classList.add("profile-heading");

  // Create table
  const table = document.createElement("table");
  table.classList.add("profile-table");

  const headerRow = document.createElement("tr");
  headerRow.innerHTML = "<th>Username</th><th>Email</th>";
  table.appendChild(headerRow);

  const users = JSON.parse(localStorage.getItem("users")) || [];
  const currentUser = localStorage.getItem("currentUser");

  if (users.length === 0) {
    const row = document.createElement("tr");
    row.innerHTML = `<td colspan="2" style="text-align:center;">NO Accounts Saved</td>`;
    table.appendChild(row);
  } else {
    users.forEach(u => {
      const row = document.createElement("tr");
      row.dataset.username = u.username;
      row.innerHTML = `<td>${u.username}</td><td>${u.email}</td>`;
      if (u.username === currentUser) row.classList.add("active");

      row.addEventListener("click", () => {
        table.querySelectorAll("tr").forEach(r => r.classList.remove("active"));
        row.classList.add("active");
        localStorage.setItem("currentUser", u.username);
        localStorage.setItem("isLoggedIn", "true");
        alert(`${u.username} is active!`);
      });

      table.appendChild(row);
    });

    // Create "Remove All Accounts" button
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove All Accounts";
    removeBtn.classList.add("remove-all-btn");
    removeBtn.style.display = "block";
    removeBtn.style.margin = "15px auto";
    removeBtn.style.padding = "8px 12px";
    removeBtn.style.cursor = "pointer";

removeBtn.addEventListener("click", () => {
  if (confirm("Are you sure you want to remove all accounts?")) {
    localStorage.removeItem("users");
    localStorage.removeItem("currentUser");
    localStorage.removeItem("isLoggedIn");
    alert("All accounts removed!");
    window.location.href = "login.html"; // Redirect to login page
  }
});


  }

  document.body.appendChild(heading);
  document.body.appendChild(table);
});



  // ---------------- RECIPE POPUP ----------------
  function fetchIngredients(meal) {
    let list = "";
    for (let i = 1; i <= 20; i++) {
      if (meal[`strIngredient${i}`]) {
        list += `<li>${meal[`strMeasure${i}`]} ${meal[`strIngredient${i}`]}</li>`;
      }
    }
    return list;
  }

  function openRecipePopup(meal) {
    hideHero(); 
    if (!recipeDetailsContent) return alert("Recipe modal not available.");

  const steps = meal.strInstructions 
        ? meal.strInstructions
            .split(/\r?\n/)                    // split by line breaks
            .filter(step => step.trim() !== "") // remove empty lines
            .map(step => step.replace(/^\d+\.\s*/, "")) // remove numbers at start only
        : ["No instructions available."];  
          let instructionsHTML="";
    steps.forEach(step =>{
      instructionsHTML += `<p>${step}</p>`;
    });
    recipeDetailsContent.innerHTML = `
     
      <h3>Ingredients:</h3>
      <ul>${fetchIngredients(meal)}</ul>

      <h3>Instructions:</h3>
      <div class="recipeInstructions">
      ${instructionsHTML}
      </div>
      ${meal.strYoutube ? `<h3>Video:</h3><iframe width="100%" height="315" src="https://www.youtube.com/embed/${meal.strYoutube.split("v=")[1]}" frameborder="0" allowfullscreen></iframe>` : ""}
    `;
    if (recipeDetailsContent.parentElement)
      recipeDetailsContent.parentElement.style.display = "block";
  }

  // ---------------- SHOW RECIPE PAGE ----------------
 function showRecipePage(queryOrCategory, isCategory = false) {
  hideHero();

  const container = document.getElementById("category-container") || document.createElement("div");
  container.id = "category-container";
  container.className = "recipe-container";
  if (isCategory) container.style.color = "black";
  if (!document.getElementById("category-container")) document.body.appendChild(container);

  container.innerHTML = `<h3>Kindly wait fetching the recipes…</h3>`;

  let url = isCategory
    ? `https://www.themealdb.com/api/json/v1/1/filter.php?c=${queryOrCategory}`
    : `https://www.themealdb.com/api/json/v1/1/search.php?s=${queryOrCategory}`;

  fetch(url)
    .then(res => res.json())
    .then(data => {
      container.innerHTML = "";
      const meals = data.meals;
      if (!meals) return (container.innerHTML = "<h4>No recipes found.</h4>");

      meals.forEach(meal => {
        const div = document.createElement("div");
        div.classList.add("recipe");
        div.innerHTML = `<img src="${meal.strMealThumb}"><h3>${meal.strMeal}</h3>`;

        const viewBtn = document.createElement("button");
        viewBtn.textContent = "View Recipe";
        viewBtn.classList.add("btn-view");
        div.appendChild(viewBtn);

        const favBtn = document.createElement("button");
        favBtn.textContent = "❤️";
        favBtn.classList.add("btn-favorite");
        div.appendChild(favBtn);

        container.appendChild(div);

        let fullMealDetails = null; // store full details if fetched

        // Category: fetch full details once for popup & origin
        if (isCategory) {
          fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`)
            .then(res => res.json())
            .then(detailData => {
              if (detailData.meals && detailData.meals[0]) {
                fullMealDetails = detailData.meals[0];

                const infoDiv = document.createElement("div");
                infoDiv.classList.add("recipe-info");
                infoDiv.innerHTML = `<p><h4>Origin:</h4> ${fullMealDetails.strArea || "N/A"}</p>`;
                div.appendChild(infoDiv);

                viewBtn.addEventListener("click", () => openRecipePopup(fullMealDetails));
              }
            })
            .catch(() => {
              const infoDiv = document.createElement("div");
              infoDiv.classList.add("recipe-info");
              infoDiv.innerHTML = `<p><h4>Origin:</h4> N/A</p>`;
              div.appendChild(infoDiv);

              viewBtn.addEventListener("click", () => alert("Failed to fetch full recipe details."));
            });
        } else {
          // Search results: origin info already available
          const infoDiv = document.createElement("div");
          infoDiv.classList.add("recipe-info");
          infoDiv.innerHTML = `<p><h4>Origin:</h4> ${meal.strArea || "N/A"}</p>`;
          div.appendChild(infoDiv);

          viewBtn.addEventListener("click", () => openRecipePopup(meal));
        }

        // Wishlist button: instant add
        favBtn.addEventListener("click", () => {
          // Add immediately with available info
          addToWishlist({
            id: meal.idMeal,
            title: meal.strMeal,
            image: meal.strMealThumb,
            area: meal.strArea || "N/A",
            category: fullMealDetails?.strCategory || "", // use if available
            instructions: fullMealDetails?.strInstructions || "", // use if available
          });

          // If full details not yet fetched (search), fetch in background to update wishlist
          if (!fullMealDetails) {
            fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`)
              .then(res => res.json())
              .then(detailData => {
                if (detailData.meals && detailData.meals[0]) {
                  const fullMeal = detailData.meals[0];
                  updateWishlist(fullMeal.idMeal, {
                    category: fullMeal.strCategory || "",
                    instructions: fullMeal.strInstructions || "",
                  });
                }
              })
              .catch(() => console.log("Background fetch failed for wishlist update"));
          }
        });

      });
    })
    .catch(() => {
      container.innerHTML = "<h4>Failed to fetch recipes. Please try again later.</h4>";
    });
}

  // ---------------- CATEGORY BUTTONS ----------------
  document.querySelectorAll(".category-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const label = btn.textContent.trim();
      const categoryMap = { "Veg": "Vegetarian", "Non-Veg": "Chicken", "Desserts": "Dessert", "Healthy": "Vegan" };
      const category = categoryMap[label] || label;
      
      showRecipePage(category, true);
      const categoriesSection = document.querySelector(".categories");
      if (categoriesSection) categoriesSection.style.display = "none";
      const homeBtn = document.querySelector(".Home-button");
      if (homeBtn) homeBtn.style.display = "none";
    });
  });

  // ---------------- SEARCH BUTTON ----------------
  if (SearchBtn && searchbox) {
    SearchBtn.addEventListener("click", e => {
      e.preventDefault();
      const query = searchbox.value.trim();
      if (!query) return;
      hideHero(); 
      showRecipePage(query);
    });
  }
});

// ---------------- ELEMENT SELECTORS ----------------
const threeDotBtn = document.getElementById("threeDotMenu");
const threeDotDropdown = document.getElementById("threeDotDropdown");
const profileBtnDropdown = document.getElementById("profileBtnDropdown");
const logoutBtnDropdown = document.getElementById("logoutBtnDropdown");
const settingsBtnDropdown = document.getElementById("settingsBtnDropdown");
const settingsPopup = document.getElementById("settingsPopup");
const darkModeCheckbox = document.getElementById("darkModeToggle");
const closeSettingsBtn = document.getElementById("closeSettings");
const wishlistSection = document.getElementById("wishlistSection");
const languageSelect = document.getElementById("languageSelect");
const wishlistBtn = document.querySelector(".Wishlist-button");

// ---------------- INITIAL DARK MODE ----------------
if (localStorage.getItem("darkMode") === "true") {
  document.body.classList.add("dark-mode");
  if (darkModeCheckbox) darkModeCheckbox.checked = true;
}

// ---------------- DOM READY ----------------
document.addEventListener("DOMContentLoaded", () => {
  // ---------------- REMOVE FIRST WHITE BUTTON ----------------
  const firstRemoveBtn = document.querySelector("button");
  if (firstRemoveBtn && firstRemoveBtn.textContent.includes("Remove All Accounts")) {
    firstRemoveBtn.remove();
  }

  // ---------------- THREE DOT MENU ----------------
  threeDotBtn?.addEventListener("click", e => {
    e.stopPropagation();
    threeDotDropdown.classList.toggle("show");
  });

  document.addEventListener("click", e => {
    if (!threeDotDropdown.contains(e.target) && e.target !== threeDotBtn) {
      threeDotDropdown.classList.remove("show");
    }
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") threeDotDropdown.classList.remove("show");
  });

  // ---------------- PROFILE ----------------
  profileBtnDropdown?.addEventListener("click", e => {
    e.stopPropagation();
    threeDotDropdown.classList.remove("show");

    // Remove any existing profile headings, tables, and buttons
    document.querySelectorAll(".profile-heading, .profile-table, .remove-accounts-btn")
      .forEach(el => el.remove());

    // Hide other sections
    document.querySelectorAll("header, .hero, main, .fe-box")
      .forEach(el => el.style.display = "none");
    document.body.classList.remove("front-page");

    // Build accounts table
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const currentUser = localStorage.getItem("currentUser");

    const heading = document.createElement("h2");
    heading.textContent = "Accounts";
    heading.classList.add("profile-heading");

    const table = document.createElement("table");
    table.classList.add("profile-table");

    const headerRow = document.createElement("tr");
    headerRow.innerHTML = "<th>Username</th><th>Email</th>";
    table.appendChild(headerRow);

    if (users.length === 0) {
      const row = document.createElement("tr");
      row.innerHTML = `<td colspan="2" style="text-align:center;">NO Accounts Saved</td>`;
      table.appendChild(row);
    } else {
      users.forEach(u => {
        const row = document.createElement("tr");
        row.dataset.username = u.username;
        row.innerHTML = `<td>${u.username}</td><td>${u.email}</td>`;
        if (u.username === currentUser) row.classList.add("active");

        row.addEventListener("click", () => {
          table.querySelectorAll("tr").forEach(r => r.classList.remove("active"));
          row.classList.add("active");
          localStorage.setItem("currentUser", u.username);
          localStorage.setItem("isLoggedIn", "true");
          alert(`${u.username} is active!`);
        });

        table.appendChild(row);
      });
    }

    // Create Remove Button
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove All Accounts";
    removeBtn.classList.add("remove-accounts-btn");
    removeBtn.style.display = "block";
    removeBtn.style.margin = "15px auto";
    removeBtn.style.padding = "8px 15px";
    removeBtn.style.backgroundColor = "#ff4d4d";
    removeBtn.style.color = "#fff";
    removeBtn.style.border = "none";
    removeBtn.style.borderRadius = "5px";
    removeBtn.style.cursor = "pointer";

    removeBtn.addEventListener("click", () => {
      if (confirm("Are you sure you want to remove all saved accounts?")) {
        localStorage.removeItem("users");
        localStorage.removeItem("currentUser");
        localStorage.removeItem("isLoggedIn");

            alert("All accounts removed!");
      window.location.href = "login.html"; // ✅ Redirect straight to login page
    }
  });

    // Append elements in order: heading → table → remove button
    document.body.appendChild(heading);
    document.body.appendChild(table);
    table.insertAdjacentElement("afterend", removeBtn); // ensures button is under the table
  });

  // ---------------- LOGOUT ----------------
  logoutBtnDropdown?.addEventListener("click", () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
    localStorage.removeItem("wishlist");
    window.location.href = "login.html";
  });

  // ---------------- SETTINGS POPUP ----------------
  settingsBtnDropdown?.addEventListener("click", e => {
    e.stopPropagation();
    threeDotDropdown.classList.remove("show");
    if (settingsPopup) settingsPopup.style.display = "block";

    if (localStorage.getItem("darkMode") === "true") {
      if (darkModeCheckbox) darkModeCheckbox.checked = true;
    } else {
      if (darkModeCheckbox) darkModeCheckbox.checked = false;
    }
  });

  closeSettingsBtn?.addEventListener("click", () => {
    if (settingsPopup) settingsPopup.style.display = "none";
  });

  // ---------------- DARK MODE TOGGLE ----------------
  darkModeCheckbox?.addEventListener("change", () => {
    if (darkModeCheckbox.checked) {
      document.body.classList.add("dark-mode");
      localStorage.setItem("darkMode", "true");
    } else {
      document.body.classList.remove("dark-mode");
      localStorage.setItem("darkMode", "false");
    }
  });

  // ---------------- WISHLIST BUTTON ----------------
  wishlistBtn?.addEventListener("click", () => {
    document.querySelectorAll("header, .hero, main, .fe-box")
      .forEach(el => el.style.display = "none");
    if (wishlistSection) wishlistSection.style.display = "block";
  });
});


